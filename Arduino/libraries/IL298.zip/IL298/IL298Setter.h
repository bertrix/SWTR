// IL298Setter.h
//
// Setter class that outputs its value to a single L298 channel with inverting logic over 2 analog pins. 
// Requires the usage of the inverted L298 library as all this does is encapsulate it for modularity
// For a single IL298 channel you need 2 setters. For a single 'true' L298 channel (IE with direct inputs) you need 3 setters.
// I'll explain this a bit further: To drive an inverted L298 you need 2 data channels, 1 for mode and the other for thrust.
// For a straight L298 you need 3 data channels, 2 for mode and 1 for thrust. 
// The setter class can only accept a single input and to keep modularity you have to maintain this throughout any setter implementation
// Thus you need 1 setter for every data channel.
/// \author  Joseph East (jeast@mymail.unisa.edu.au)
///
// Copyleft (C) 2011 Joseph East
// 

#ifndef IL298Setter_h
#define IL298Setter_h
#include "Setter.h"

class IL298;

/////////////////////////////////////////////////////////////////////
/// \class IL298Setter IL298Setter.h <IL298Setter.h>
/// \brief Setter class that outputs its value to a HBridge configured on 2 output Setter
///
/// A HBridge is used to drive a motor in forward and reverse directions. It requires 2 Setters as output:
/// one to drive the motor forwards and one to drive it in reverse. When driving forward the reverse 
/// output is 0 and vice versa.
///
/// Typically the outputs would be AnalogSetters to control a motor through a pair of analog outputs,
/// but could be ServoSetter, AccelStepperSpeedSetter 
/// or AccelStepperPositionSetter or any other combination.
///
class IL298Setter : public Setter
{   
public:
    /// \param[in] targetA The Setter to use for output A. 
	/// The boolean indicates whether this setter controls the mode or the thrust. 
	/// A true indicates thrust, a false indicates mode.
	/// You need 1 of each for control a single IL298 channel.
    IL298Setter(IL298* targetA, bool mode);

    /// Input the value to be used to set the output Setter.
    /// Standard byte parameters, 
	/// 0->255 for thrust, 0 being stopped state
    /// for mode parameters a 0 indicates backwards, non zero is forwards.
    /// 
    /// 
    /// 
    /// \param[in] value The input value to set.
    virtual void input(int value);

    /// Called when the source of input data is lost, and the Setter is required to fail in a safe way.
    /// Calls the failsafes of targetA and targetB
    virtual void failsafe();

protected:


private:
    /// The B output Setter. targetA is the setter that is included in the Setter class
    IL298* _targetA;
	bool _mode;
};

#endif 
