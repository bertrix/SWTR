A simple driver class for the DF-robot shield, any L298 board with an inverter.

Designed with the S.W.A.T drone in mind, but can be used elsewhere.

Essentially just makes to motors turn.

As the shield has hard wired pins there shouldn't be any need to change them.

For information about the shield consult the DF-Robot website

http://www.dfrobot.com/wiki/index.php?title=Arduino_Motor_Shield_%28L298N%29_%28SKU:DRI0009%29

Arduino 00xx/1.0 compatible!



