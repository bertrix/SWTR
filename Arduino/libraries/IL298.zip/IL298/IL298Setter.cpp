// IL298Setter.cpp
//
// Template for a CPP file
// \author  Joseph East (jeast@mymail.unisa.edu.au)
//
// Copyleft (C) 2011 Joseph East
// 

#include "IL298Setter.h"
#include <IL298.h>

/////////////////////////////////////////////////////////////////////
IL298Setter::IL298Setter(IL298* targetA, bool mode) : Setter()
{
    _targetA = targetA;
	_mode = mode;
}

/////////////////////////////////////////////////////////////////////
void IL298Setter::input(int value)
{
		#ifdef DEBUG
		_previousValue = value;
		#endif
		if(_mode)
		{
		
    	// Clip and scale the value to suit the H-bridge
    	if (value < 0)
			{
			value = 0;
			}
    	if (value > 255)
			{
				value = 255;
			}
    	value = ((long)value * 180) / 255;
			_targetA->setSpeed(value);
		}
    // Output the value to the H-brdige
    //if (_targetA)
	
	else
		_targetA->setDirection((bool)value);
}
  	

/////////////////////////////////////////////////////////////////////
void IL298Setter::failsafe()
{
	_targetA->failsafe();
}


