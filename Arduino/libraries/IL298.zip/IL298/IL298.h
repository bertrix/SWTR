// IL298.cpp
// This file defines an L298 motor controller with an attached inverter
// For simplicity we define 1 controller per class
// An L298 normally has 2 in a single package, so declare appropriately

#ifndef IL298_h
#define IL298_h
class IL298
{
	public:
	IL298();
	IL298 (int, int);
	void setSpeed(int);
	void setDirection(bool);
	void failsafe();
	void pinSetter(int, int);
	bool isFail();

	private:
	
	void truthTeller(bool, bool, int);
	int _speedPin, _control, speedBuf; // speed, direction pins and speed buffer variable. _speedPin must be PWM enabled. Control is GPIO
	bool chanState, safeMode; // enable and safemode variables
	
};
#endif 
