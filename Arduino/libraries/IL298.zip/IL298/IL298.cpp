// IL298.cpp
// This file defines an L298 motor controller with built-in inverter
// The inverter reduces requisite control signal count to 1 line per channel
// at the loss of 'fast brake' 
// 

#include "IL298.h"
#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

IL298::IL298()
{
	// Truthtable inputs
	chanState = false; // This is the primary channel input, false is reverse, true is forward (I think...)
	safeMode = false; // safemode, if switched then this channel is disabled
	// Speed inputs
	speedBuf = 0; // This stores the current speed for comparison later on
}

IL298::IL298(int inAA, int sA)
{
	// define the pins
	_control = inAA;
	_speedPin = sA;
	
	// set all declared pins above as outputs
	pinMode(inAA, OUTPUT);
	pinMode(sA, OUTPUT);
	
	// state buffers
	
	// Truthtable inputs
	chanState = false;
	safeMode = false;
	// Speed inputs
	speedBuf = 0;
}

void IL298::pinSetter(int inAA, int sA)
{
	_control = inAA;
	_speedPin = sA;
	
	pinMode(inAA, OUTPUT);
	pinMode(sA, OUTPUT);
}


void IL298::setSpeed(int sA)
{	
	safeMode = false;
	
	// Adjust the speed
	if(speedBuf != sA)
	analogWrite(_speedPin, sA);
	
	// Update the state buffer
	speedBuf = sA;
	
}

void IL298::setDirection(bool inAA)
{
	safeMode = false;
	// Set the function pins
	truthTeller(inAA, chanState, _control);
	// update the state buffer
	chanState = inAA;
}

bool IL298::isFail()
{
	return safeMode;
}

void IL298::failsafe()
{
	safeMode = true;
	speedBuf = 0;
	analogWrite(_speedPin, 0);
}

// The truthteller function affects the truthtable driving the motor. It compares incoming signals with what's in the buffer; 
// If theres a difference it switches else it does nothing.
// 'in' is the input parameter, 'statebuffer' is well, the statebuffer, 'pin' is the truthtable pin for the motor.

void IL298::truthTeller(bool in, bool statebuffer, int pin)
{
	if(in != statebuffer)
	{
		if(in)
			digitalWrite(pin, HIGH);
		else
			digitalWrite(pin, LOW);
	}
}


